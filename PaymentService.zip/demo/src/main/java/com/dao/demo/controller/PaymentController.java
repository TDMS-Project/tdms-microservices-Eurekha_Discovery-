package com.dao.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PaymentController {

    @GetMapping("/processPayment")
    public String processPayment(@RequestParam String orderId) {
        return "Payment processed successfully for Order ID: " + orderId + " Customer Id : OD0254898254"+" Customer Name : Er.Rohit Shirsat";
    }
}
