package com.blogs.dtos;

import java.time.LocalDateTime;

public class OrderItemDto {
	    private String itemName;
	    private String orderStatus;
	    private LocalDateTime orderDate;
	   
}
